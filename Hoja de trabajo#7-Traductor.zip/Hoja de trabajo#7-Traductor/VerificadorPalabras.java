/**
 * Universidad del Valle de Guatemala
 * Estructura de datos - Sección 10
 * @author Christopher García - 20541
 * @version 2
 * Referencias de ejemplos proporcionados por el catedrático
 */
public class VerificadorPalabras implements Comparable<VerificadorPalabras>{

    String espanol;
    String ingles;
    String frances;
    String Data;

    public VerificadorPalabras(String espanol, String ingles, String frances){
    
        this.espanol=espanol;
        this.ingles=ingles;
        this.frances=frances;
    }

    public VerificadorPalabras(String u){
        Data = u;
    }

    public String getWord(String k){
        if(Data == null) {
            if (k.equals("espanol")) {
                return espanol;
            } else if (k.equals("ingles")) {
                return ingles;
            } else if (k.equals("frances")) {
                return frances;
            } else return null;
        } else {
            return Data;
        }
    }

    @Override
    public int compareTo(VerificadorPalabras o) {
        if(o.getData() == null){
            return getWord(Main.Lenguaje).compareTo(o.getWord(Main.Lenguaje));
        } else {
            return getWord(Main.Lenguaje).compareTo(o.getData());
        }

    }

    public String getData(){
        return Data;
    }

    @Override
    public String toString() {
        return "Traducciones\n"+ "Espanol: "+ espanol + "\nIngles: "+ ingles + "\nFrances: "+ frances + "\n";
    }

}
