/**
 * Universidad del Valle de Guatemala
 * Estructura de datos - Sección 10
 * @author Christopher García - 20541
 * @version 2
 * Referencias de: https://www.baeldung.com/java-binary-tree
 */
public class Binarytree<E extends Comparable<E>>{

    Nodo<E> root;


    private Nodo<E> addRecursive(Nodo<E> current, E value) {

        if (current == null) {
            return new Nodo<E>(value);
        }

        if (((String) value).compareTo((String) current.getValue()) < 0) {
            current.right = addRecursive(current.right, value);
        } else if (((String) value).compareTo((String) current.getValue()) > 0) {
            current.left = addRecursive(current.left, value);
        } else {
            // value already exists
            return current;
        }

        return current;
    }

    public void add(E value) {
        root = addRecursive(root, value);
    }

    public Nodo<E> locateRecursive(Nodo<E> root, E value)
    {
        E rootValue = root.getValue();
        Nodo<E> child;

        // found at root: done
        if (((String) rootValue).compareTo((String) value) == 0) return root;
        // look left if less-than, right if greater-than
        if (((String) value).compareTo((String) rootValue) < 0)
        {
            child = root.right;
        } else {
            child = root.left;
        }
        // no child there: not in tree, return this Nodo,
        // else keep searching
        if (child == null) {
            return null;
        } else {
            return locateRecursive(child, value);
        }
    }

    public Nodo<E> locate(E value){
        return locateRecursive(root, value);
    }

    private void printInorderRecursive(Nodo<E> Nodo)
    {
        if (Nodo == null)
            return;

        /* first recur on left child */
        printInorderRecursive(Nodo.right);

        /* then print the data of Nodo */
        System.out.print(Nodo.getValue().toString());

        /* now recur on right child */
        printInorderRecursive(Nodo.left);
    }

    public void printInorder(){
        printInorderRecursive(root);
    }


}
