/**
 * Universidad del Valle de Guatemala
 * Estructura de datos - Sección 10
 * @author Christopher García - 20541
 * @version 2
 * Referencia del libro de texto utilizado y ejemplos de la clase
 */
public class Association<K,V> implements MapEntry<K,V>
{

    protected K theKey; 
    protected V theValue; 

    public Association(K key, V value)
    {
        
        theKey = key;
        theValue = value;
    }

    public Association()
    {
        this(null,null);
    }

    public boolean equals(Object other)
    {
        Association<K, V> otherAssoc = (Association<K, V>) other;
        return getKey().equals(otherAssoc.getKey());
    }
    
    public int hashCode()
    {
        return getKey().hashCode();
    }
    
    public V getValue()
    {
        return theValue;
    }

    public K getKey()
    {
        return theKey;
    }

    public V setValue(V value)
    {
        V oldValue = theValue;
        theValue = value;
        return oldValue;
    }

    public String toString()
    {
        StringBuffer s = new StringBuffer();
        s.append("Palabra(key): "+getKey()+"\n\nTraducciones(Value): \n"+getValue()+"\n");
        return s.toString();
    }
    
}
