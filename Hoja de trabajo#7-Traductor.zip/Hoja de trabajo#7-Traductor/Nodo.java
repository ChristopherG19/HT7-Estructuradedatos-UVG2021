/**
 * Universidad del Valle de Guatemala
 * Estructura de datos - Sección 10
 * @author Christopher García - 20541
 * @version 2
 */
public class Nodo<E>{
    
    E value;
    Nodo<E> left;
    Nodo<E> right;

    Nodo(E value) {
        this.value = value;
        right = null;
        left = null;
    }

    /** 
     * @return E
     */
    public E getValue(){
        return value;
    }

}
