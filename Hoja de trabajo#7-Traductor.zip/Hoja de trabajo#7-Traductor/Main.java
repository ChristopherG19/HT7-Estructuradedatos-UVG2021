/**
 * Universidad del Valle de Guatemala
 * Estructura de datos - Sección 10
 * @author Christopher García - 20541
 * @version 2
 */
import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    
    private static Scanner scan;
    public static String Lenguaje;
    public static String LenguajeNuevo;

    public static void main(String[] args) {
        
        scan = new Scanner(System.in);
        System.out.println("\n\t\t-----> Traductor VeryGoodNice <-----\n");
        System.out.println("Para comenzar necesito un archivo para alimentar el diccionario");
        
        boolean verificador1 = true;
        while(verificador1){     
            try {
                System.out.print("Ingresa el nombre del archivo por favor: ");
                String input = scan.nextLine();
                System.out.println();
                if(input.equals("diccionario.txt") || input.equals("Diccionario.txt")){
                    ArrayList<String> palabras = leerArchivo(input);
                    String temporal = ArchivoToString(palabras);
                    String[] lineas = temporal.split("\n");
                    String[] palabrasD;
                    System.out.println("Diccionario completo");
                    for(int i = 0; i < lineas.length; i++){
                      palabrasD = lineas[i].split(",");
                      String keyIngles = palabrasD[0];
                      String valueIngles = "Ingles: " + palabrasD[0] + "\nEspanol: " + palabrasD[1] + "\nFrances: " + palabrasD[2];
                      Association<String, String> aso = new Association<String, String>(keyIngles, valueIngles);
                      System.out.println(aso);
                    }
                    
                    verificador1 = false;
                } else {
                    System.out.println("Lo siento, este archivo no puede alimentar el diccionario");
                }
            } catch (Exception e) {
                System.out.println("ERROR!!! Archivo leido incorrectamente");
            }
        }

        System.out.println();
        boolean verificador2 = true;
        while(verificador2){
          try {
            System.out.print("\nIngresa el nombre del archivo a traducir por favor: ");
            String input = scan.nextLine();
            System.out.println();
            if(input.equals("texto.txt") || input.equals("Texto.txt")){
              ArrayList<String> palabras = leerArchivo(input);
              String temporal = ArchivoToString(palabras);
              String[] lineas = temporal.split("\n");
              for(int i = 0; i < lineas.length; i++){
                String resultado = lineas[i];
                String result = resultado.replaceAll("\\p{Punct}", "");
                System.out.println(result);
                String[] palabrau = result.split(" ");
                for(int j =0; j < palabrau.length; j++){
                  System.out.println(palabrau[j]);
                }
              }           
              verificador2 = false;
            } else {
              System.out.println("Lo siento, este archivo no puede alimentar el diccionario");
            }

            System.out.println("\nEn que idioma se encuentra el documento?: \n");
            System.out.println("1) Espanol");
            System.out.println("2) Ingles");
            System.out.println("3) Frances\n");
            System.out.print("Idioma: ");
            String idioma = scan.nextLine();

            if(idioma.equals("1")){
              System.out.println("Entendido, el documento esta en: Espanol");
              boolean verificador3 = true;
              while(verificador3){
                System.out.println("\nDeseas traducir el archivo al: \n");
                System.out.println("1) Ingles");
                System.out.println("2) Frances\n");
                System.out.print("Traducir al: "); 
                String idiomaTra = scan.nextLine();
                if(idiomaTra.equals("1")){
                  System.out.println("Se traducira al Ingles");
                  verificador3 = false;
                } else if (idiomaTra.equals("2")){
                  System.out.println("Se traducira al Frances");
                  verificador3 = false;
                } else {
                  System.out.println("Lo sentimos, no es una opción válida");
                }
              }
                  
              verificador2 = false;

            } else if(idioma.equals("2")){
              System.out.println("Entendido, el documento esta en: Ingles");
              boolean verificador3 = true;
              while(verificador3){
                System.out.println("\nDeseas traducir el archivo al: \n");
                System.out.println("1) Espanol");
                System.out.println("2) Frances\n");
                System.out.print("Traducir al: "); 
                String idiomaTra = scan.nextLine();
                if(idiomaTra.equals("1")){
                  System.out.println("Se traducira al Espanol");
                  verificador3 = false;
                } else if (idiomaTra.equals("2")){
                  System.out.println("Se traducira al Frances");
                  verificador3 = false;
                } else {
                  System.out.println("Lo sentimos, no es una opción válida");
                }
              }
              verificador2 = false;
                      
            } else if(idioma.equals("3")){
              System.out.println("Entendido, el documento esta en: Frances");
              boolean verificador3 = true;
              while(verificador3){
                System.out.println("\nDeseas traducir el archivo al: \n");
                System.out.println("1) Ingles");
                System.out.println("2) Espanol\n");
                System.out.print("Traducir al: "); 
                String idiomaTra = scan.nextLine();
                if(idiomaTra.equals("1")){
                  System.out.println("Se traducira al Ingles");
                  verificador3= false;
                } else if (idiomaTra.equals("2")){
                  System.out.println("Se traducira al Espanol");
                  verificador3 = false;
                } else {
                  System.out.println("Lo sentimos, no es una opción válida");
                }
              }
              verificador2 = false;

            } else {
              System.out.println("No es una opción válida lo siento\n");
            }

          } catch (Exception e) {
            System.out.println("No es una opción válida lo siento\n");
          }
       }
    }

  /**
  * Método leerArchivo
  * Se lee el contenido del archivo y se guarda en un ArrayList
  * @param nombreArchivo: Recibe el nombre del archivo 
  * @return: Arraylist con las lineas del archivo
  */
  public static ArrayList<String> leerArchivo(String nombreArchivo){

    /**
    * Se crea un Arraylist que almacenara cada linea del archivo
    */
    ArrayList<String> Info = new ArrayList<String>();

    /**
    * Try-catch como medida de seguridad por si en dado caso el archivo no existe
    */ 
    try {

      /**
      * Se lee cada linea del archivo y se agrega al ArrayList
      */
      File Archivo = new File(nombreArchivo);
      Scanner Lector = new Scanner(Archivo);

      while(Lector.hasNextLine()){
        String Line = Lector.nextLine();
        Info.add(Line);
      }

      Lector.close();
    } catch (Exception e){
      System.out.println("Error! Archivo no encontrado");
      e.printStackTrace();
    }


    return Info;
  }

  /**
  * Método ArchivoToString
  * Se convierte en un String el ArrayList de un archivo
  * @param Lista: Arraylist que contiene las lineas de un archivo
  * @return Acumulador: String que contiene toda la información del archivo
  */
  public static String ArchivoToString(ArrayList<String> Lista){
    /**
    * String vacío para acumular las lineas del archivo
    */
    String Acumulador = "";
    
    /**
    * Por cada linea del Arraylist se agrega la misma al Acumulador con un salto de
    * linea 
    */
    for(String a: Lista){
      Acumulador += (a + "\n");
    }
    Acumulador = Acumulador.trim();
    return Acumulador;
  }

}
