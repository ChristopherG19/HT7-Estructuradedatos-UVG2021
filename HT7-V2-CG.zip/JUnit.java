/**
 * Universidad del Valle de Guatemala
 * Estructura de datos - Sección 10
 * @author Christopher García - 20541
 * @version 2
 */
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import org.junit.Test;   
    
public class JUnit {
   
    /**
     * Test#1: Verifica que el sistema de agregar y buscar funcione correctamente
     * También se comprueba que se orden de la forma correcta: InOrder
     */
    @Test
    public void AgregacionYBusqueda() {
        
        /**
         * Se crean los árboles de prueba
         */
        Binarytree<VerificadorPalabras> ArbolA = new Binarytree<VerificadorPalabras>();
        Binarytree<VerificadorPalabras> ArbolB = new Binarytree<VerificadorPalabras>();
        Binarytree<VerificadorPalabras> ArbolC = new Binarytree<VerificadorPalabras>();
        Binarytree<VerificadorPalabras> ArbolD = new Binarytree<VerificadorPalabras>();
        
        /**
         * Se agregan datos a cada árbol de manera desordenada
         */
        ArbolA.add("Abigail");
        ArbolA.add("Zoe");
        ArbolA.add("Juan");

        ArbolB.add("Pedro");
        ArbolB.add("Brandon");
        ArbolB.add("Amaya");

        ArbolC.add("Armin");
        ArbolC.add("Hange");
        ArbolC.add("Eren");

        /**
         * Se imprimen los árboles de la manera InOrder que si todo
         * sale correctamente los nombres se ordenan de manera alfabética
         */
        System.out.print("Arbol A: ");
        ArbolA.printInorder();
        System.out.print("\nArbol B: ");
        ArbolB.printInorder();
        System.out.print("\nArbol C: ");
        ArbolC.printInorder();

        /**
         * Se comprueba la búsqueda, como el arbol D no tiene
         * nada al principio se espera que su nodo se encuentre vacío
         * 
         * Luego de agregar un dato se espera lo contrario, que ya no se encuentre vacío este
         * mismo nodo
         */
        assertNull(ArbolD.root);
        ArbolA.add("A");
        assertNotNull(ArbolA.root);

    }
}
    