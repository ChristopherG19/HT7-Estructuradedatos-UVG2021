/**
 * Universidad del Valle de Guatemala
 * Estructura de datos - Sección 10
 * @author Christopher García - 20541
 * @version 2
 * Referencias de: https://www.baeldung.com/java-binary-tree
 */
public class Binarytree<E extends Comparable<E>>{

    Nodo<E> root;

    /** 
     * Se agrega de manera recursiva un valor hasta quedar en su posición correcta
     * @param current
     * @param palabrasD
     * @return Nodo<E>
     */
    private Nodo<E> addRecursive(Nodo<E> current, String palabrasD) {

        if (current == null) {
            return new Nodo<E>(palabrasD);
        }

        /*System.out.println("Nodo: "+current);
        System.out.println("Value: "+palabrasD);*/

        if (palabrasD.compareTo(current.getValue()) < 0) {
            current.right = addRecursive(current.right, palabrasD);
        } else if (palabrasD.compareTo(current.getValue()) > 0) {
            current.left = addRecursive(current.left, palabrasD);
        } else {
            // value already exists
            return current;
        }

        return current;
    }

    /** 
     * Se agrega un valor al árbol
     * @param palabrasD
     */
    public void add(String palabrasD) {
        root = addRecursive(root, palabrasD);
    }

    /** 
     * Se localiza un nodo dentro del árbol
     * @param root
     * @param value
     * @return Nodo<E>
     */
    public Nodo<E> locateRecursive(Nodo<E> root, String value)
    {
        String rootValue = root.getValue();
        Nodo<E> child;

        // found at root: done
        if (rootValue.compareTo(value) == 0) return root;
        // look left if less-than, right if greater-than
        if (value.compareTo(rootValue) < 0)
        {
            child = root.right;
        } else {
            child = root.left;
        }
        // no child there: not in tree, return this Nodo,
        // else keep searching
        if (child == null) {
            return null;
        } else {
            return locateRecursive(child, value);
        }
    }

    /** 
     * Se localiza el valor de un nodo
     * @param value
     * @return Nodo<E>
     */
    public Nodo<E> locate(String value){
        return locateRecursive(root, value);
    }

    /** 
     * Se imprime el arbol de manera InOrder
     * @param Nodo
     */
    private void printInorderRecursive(Nodo<E> Nodo)
    {
        if (Nodo == null)
            return;

        /* first recur on left child */
        printInorderRecursive(Nodo.right);

        /* then print the data of Nodo */
        System.out.print(Nodo.getValue().toString()+ " ");

        /* now recur on right child */
        printInorderRecursive(Nodo.left);
    }

    /**
     * Se imprimen los valores en orden
     */
    public void printInorder(){
        printInorderRecursive(root);
    }


}
