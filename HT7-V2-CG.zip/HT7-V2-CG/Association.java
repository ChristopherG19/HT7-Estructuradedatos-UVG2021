/**
 * Universidad del Valle de Guatemala
 * Estructura de datos - Sección 10
 * @author Christopher García - 20541
 * @version 2
 * Referencia del libro de texto utilizado y ejemplos de la clase
 */
public class Association<K,V> implements MapEntry<K,V>
{

    /**
     * Parámetros
     */
    protected K theKey; 
    protected V theValue; 

    /**
     * Constructor de la clase
     * @param key: Llave para encontrar la asociación
     * @param value: Valor de la asociación
     */
    public Association(K key, V value)
    {
        theKey = key;
        theValue = value;
    }
    
    /** 
     * Método equals para comparar
     * @param other: objeto con el que se debe comparar
     * @return boolean: true si son iguales, false si no lo son
     */
    public boolean equals(Association<K, V> other)
    {
        Association<K, V> otherAssoc = other;
        return getKey().equals(otherAssoc.getKey());
    }
    
    /** 
     * @return int
     */
    public int hashCode()
    {
        return getKey().hashCode();
    }
    
    /** 
     * @return V: Retorna el valor de la asociación
     */
    public V getValue()
    {
        return theValue;
    }
    
    /** 
     * @return K: Retorna el key de la asociación
     */
    public K getKey()
    {
        return theKey;
    }
    
    /** 
     * Modicación del valor de una asociación
     * @param value: valor que modificara el antiguo
     * @return V: Retorna el valor antiguo de la asociación
     */
    public V setValue(V value)
    {
        V oldValue = theValue;
        theValue = value;
        return oldValue;
    }

    /** 
     * @return String: Información de la asociación
     */
    public String toString()
    {
        StringBuffer s = new StringBuffer();
        s.append("Palabra(key): "+ getKey()+"\n\nTraducciones(Value): \n"+getValue()+"\n");
        return s.toString();
    }
    
}
