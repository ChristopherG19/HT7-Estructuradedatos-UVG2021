/**
 * Universidad del Valle de Guatemala
 * Estructura de datos - Sección 10
 * @author Christopher García - 20541
 * @version 2
 * Se tomaron referencias de ejemplos vistos en clase y material de apoyo
 */
/**
 * Imports
 */
import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Inicio de clase Main
 */
public class Main{
    
    /**
     * Atributos para conocer las decisiones del usuario
     */
    private static Scanner scan;
    public static String Lenguaje;
    public static String LenguajeNuevo;

    /** 
     * Main
     * @param args
     */
    public static void main(String[] args) {
        
      /**
       * Inicio del programa
       */
      scan = new Scanner(System.in);
      System.out.println("\n\t\t-----> Traductor VeryGoodNice <-----\n");
      System.out.println("Para comenzar necesito un archivo para alimentar el diccionario");
      Binarytree<VerificadorPalabras> ArbolEspanol= new Binarytree<VerificadorPalabras>();
      Binarytree<VerificadorPalabras> ArbolIngles= new Binarytree<VerificadorPalabras>();
      Binarytree<VerificadorPalabras> ArbolFrances= new Binarytree<VerificadorPalabras>();
      //Binarytree<VerificadorPalabras> ArbolT= new Binarytree<VerificadorPalabras>();
        
      /**
       * Ciclo While que permite al usuario realizar todas las operaciones que necesite
       */
      boolean verificador1 = true;
      while(verificador1){     
        /**
         * Try-catch para leer el archivo que alimenta el diccionario con asociaciones
         */
          try {
              System.out.print("Ingresa el nombre del archivo por favor: ");
              String input = scan.nextLine();
              System.out.println();
              if(input.equals("diccionario.txt") || input.equals("Diccionario.txt")){
                  ArrayList<String> palabras = leerArchivo(input);
                  String temporal = ArchivoToString(palabras);
                  String[] lineas = temporal.split("\n");
                  String[] palabrasD;
                  System.out.println("Diccionario completo");
                  for(int i = 0; i < lineas.length; i++){
                    palabrasD = lineas[i].split(",");
                    String keyIngles = palabrasD[0];
                    String valueIngles = "Ingles: " + palabrasD[0] + "\nEspanol: " + palabrasD[1] + "\nFrances: " + palabrasD[2];             
                    Association<String, String> aso = new Association<String, String>(keyIngles, valueIngles);
                    System.out.println(aso);

                    ArbolEspanol.add(palabrasD[0]);
                    ArbolIngles.add(palabrasD[1]);
                    ArbolFrances.add(palabrasD[2]);

                    /*VerificadorPalabras palaes = new VerificadorPalabras(palabrasD[1], palabrasD[0], palabrasD[2]);
                    VerificadorPalabras palain = new VerificadorPalabras(palabrasD[0], palabrasD[1], palabrasD[2]);
                    VerificadorPalabras palafr = new VerificadorPalabras(palabrasD[1], palabrasD[0], palabrasD[2]);*/
                    /*ArbolEspanol.add(palaes);
                    ArbolIngles.add(palain);
                    ArbolFrances.add(palafr);
                    VerificadorPalabras Tod = new VerificadorPalabras(palabrasD[0], palabrasD[1], palabrasD[2]);
                    System.out.println(Tod);
                    //ArbolT.add(Tod);*/
                  }
                    
                  verificador1 = false;
              } else {
                  System.out.println("Lo siento, este archivo no puede alimentar el diccionario");
              }
          } catch (Exception e) {
              System.out.println(e);
              System.out.println("ERROR!!! Archivo leido incorrectamente");
          }
      }

      /**
       * Se muestran los arboles por idioma ordenados
       */
      System.out.println("\n------------------------------------");
      System.out.println("     Arbol en Español ordenado");
      ArbolEspanol.printInorder();
      System.out.println("\n\n     Arbol en Ingles ordenado");
      ArbolIngles.printInorder();
      System.out.println("\n\n     Arbol en Frances ordenado");
      ArbolFrances.printInorder();
      System.out.println("\n------------------------------------\n");

      /**
       * Inicio del menu que controla el lenguaje del documento, el lenguaje al que se traducirá y la lectura del documento en sí
       */
      boolean verificador2 = true;
      while(verificador2){
        try {
        
          System.out.println("\nEn que idioma estara el documento que quieres traducir?: \n");
          System.out.println("1) Espanol");
          System.out.println("2) Ingles");
          System.out.println("3) Frances\n");
          System.out.print("Idioma: ");
          String idioma = scan.nextLine();

          if(idioma.equals("1")){
            System.out.println("El documento estara en: Espanol");
            Lenguaje = "Espanol";
            boolean verificador3 = true;
            while(verificador3){
              System.out.println("\nDeseas traducir el archivo al: \n");
              System.out.println("1) Ingles");
              System.out.println("2) Frances\n");
              System.out.print("Traducir al: "); 
              String idiomaTra = scan.nextLine();
              if(idiomaTra.equals("1")){
                System.out.println("Se traducira al Ingles");
                LenguajeNuevo = "Ingles";
                verificador3 = false;
              } else if (idiomaTra.equals("2")){
                System.out.println("Se traducira al Frances");
                LenguajeNuevo = "Frances";
                verificador3 = false;
              } else {
                System.out.println("Lo sentimos, no es una opción válida");
              }
            }
                  
            verificador2 = false;

          } else if(idioma.equals("2")){
            System.out.println("El documento estara en: Ingles");
            Lenguaje = "Ingles";
            boolean verificador3 = true;
            while(verificador3){
              System.out.println("\nDeseas traducir el archivo al: \n");
              System.out.println("1) Espanol");
              System.out.println("2) Frances\n");
              System.out.print("Traducir al: "); 
              String idiomaTra = scan.nextLine();
              if(idiomaTra.equals("1")){
                System.out.println("Se traducira al Espanol");
                LenguajeNuevo = "Espanol";
                verificador3 = false;
              } else if (idiomaTra.equals("2")){
                System.out.println("Se traducira al Frances");
                LenguajeNuevo = "Frances";
                verificador3 = false;
              } else {
                System.out.println("Lo sentimos, no es una opción válida");
              }
            }
            verificador2 = false;
                      
          } else if(idioma.equals("3")){
            System.out.println("El documento estara en: Frances");
            Lenguaje = "Frances";
            boolean verificador3 = true;
            while(verificador3){
              System.out.println("\nDeseas traducir el archivo al: \n");
              System.out.println("1) Ingles");
              System.out.println("2) Espanol\n");
              System.out.print("Traducir al: "); 
              String idiomaTra = scan.nextLine();
              if(idiomaTra.equals("1")){
                System.out.println("Se traducira al Ingles");
                LenguajeNuevo = "Ingles";
                verificador3= false;
              } else if (idiomaTra.equals("2")){
                System.out.println("Se traducira al Espanol");
                LenguajeNuevo = "Espanol";
                verificador3 = false;
              } else {
                System.out.println("Lo sentimos, no es una opción válida");
              }
            }
            verificador2 = false;

          } else {
            System.out.println("No es una opción válida lo siento\n");
          }

          /**
           * Se lee el archivo del usuario 
           */
          boolean verificador6 = true;
          while(verificador6){
            System.out.print("\nIngresa el nombre por favor: ");
            String input = scan.nextLine();
            System.out.println();
            if(input.equals("texto.txt") || input.equals("Texto.txt")){
              ArrayList<String> palabras = leerArchivo(input);
              String temporal = ArchivoToString(palabras);
              String[] lineas = temporal.split("\n");
              //String result = "";

              System.out.println("Texto original: " + temporal);

              for(int i = 0; i < lineas.length; i++){
                String resultado = lineas[i].toLowerCase();
                temporal = resultado.replaceAll("\\p{Punct}", "");
                //String[] palabrau = temporal.split(" ");
                /*for (int j=0; j<palabrau.length; j++){
                  if (ArbolEspanol.locate(new VerificadorPalabras(palabrau[i])) != null){
                      palabrau[i] = ArbolEspanol.locate(new VerificadorPalabras(palabrau[i])).value.getWord(LenguajeNuevo);
                  }
                }

                temporal = String.join(" ",palabrau);
                System.out.println("\nTexto traducido:");
                System.out.println(temporal);

                for(int j =0; j < palabrau.length; j++){
                  System.out.println(palabrau[j]);
                }*/
              }  
                
              verificador6 = false;
              System.out.println();

            } else {
              System.out.println("Lo siento, este archivo no puede alimentar el diccionario");
            }
          }
        } catch (Exception e) {
          System.out.println("No es una opción válida lo siento\n");
        }
      }
    
    }
  /**
  * Método leerArchivo
  * Se lee el contenido del archivo y se guarda en un ArrayList
  * @param nombreArchivo: Recibe el nombre del archivo 
  * @return: Arraylist con las lineas del archivo
  */
  public static ArrayList<String> leerArchivo(String nombreArchivo){

    /**
    * Se crea un Arraylist que almacenara cada linea del archivo
    */
    ArrayList<String> Info = new ArrayList<String>();

    /**
    * Try-catch como medida de seguridad por si en dado caso el archivo no existe
    */ 
    try {

      /**
      * Se lee cada linea del archivo y se agrega al ArrayList
      */
      File Archivo = new File(nombreArchivo);
      Scanner Lector = new Scanner(Archivo);

      while(Lector.hasNextLine()){
        String Line = Lector.nextLine();
        Info.add(Line);
      }

      Lector.close();
    } catch (Exception e){
      System.out.println("Error! Archivo no encontrado");
      e.printStackTrace();
    }


    return Info;
  }

  /**
  * Método ArchivoToString
  * Se convierte en un String el ArrayList de un archivo
  * @param Lista: Arraylist que contiene las lineas de un archivo
  * @return Acumulador: String que contiene toda la información del archivo
  */
  public static String ArchivoToString(ArrayList<String> Lista){
    /**
    * String vacío para acumular las lineas del archivo
    */
    String Acumulador = "";
    
    /**
    * Por cada linea del Arraylist se agrega la misma al Acumulador con un salto de
    * linea 
    */
    for(String a: Lista){
      Acumulador += (a + "\n");
    }
    Acumulador = Acumulador.trim();
    return Acumulador;
  }

}
