/**
 * Universidad del Valle de Guatemala
 * Estructura de datos - Sección 10
 * @author Christopher García - 20541
 * @version 2
 * Referencias de ejemplos proporcionados por el catedrático
 */
/**
 * Clase que verifica en que idioma están las palabras y las compara
 */
public class VerificadorPalabras implements Comparable<VerificadorPalabras>{

    /**
     * Parámetros 
     */
    String espanol;
    String ingles;
    String frances;
    String Data;

    /**
     * Constructor para definir las palabras con sus traducciones
     * @param ingles
     * @param espanol
     * @param frances
     */
    public VerificadorPalabras(String ingles, String espanol, String frances){ 
        this.espanol=espanol;
        this.ingles=ingles;
        this.frances=frances; 
    }
    
    /**
     * Si es un valor se toma como dato
     * @param u
     */
    public VerificadorPalabras(String u){
        Data = u;
    }
    
    /** 
     * Se obtiene el idioma de las palabras
     * @param k
     * @return String
     */
    public String getWord(String k){
        if(Data == null) {
            if (k.equals("espanol")) {
                return espanol;
            } else if (k.equals("ingles")) {
                return ingles;
            } else if (k.equals("frances")) {
                return frances;
            } else return null;
        } else {
            return Data;
        }
    }

    /** 
     * Se comparan las palabras
     * @param o
     * @return int
     */
    @Override
    public int compareTo(VerificadorPalabras o) {
        if(o.getData() == null){
            return getWord(Main.Lenguaje).compareTo(o.getWord(Main.Lenguaje));
        } else {
            return getWord(Main.Lenguaje).compareTo(o.getData());
        }

    }

    /** 
     * Se obtiene el dato 
     * @return String
     */
    public String getData(){
        return Data;
    }

    
    /** 
     * Información de las palabras
     * @return String
     */
    @Override
    public String toString() {
        return "Traducciones\n"+ "Espanol: "+ espanol + "\nIngles: "+ ingles + "\nFrances: "+ frances + "\n";
    }

}
