/**
 * Universidad del Valle de Guatemala
 * Estructura de datos - Sección 10
 * @author Christopher García - 20541
 * @version 2
 * Referencias del libro de texto y ejemplos de la clase
 */
public class Nodo<E>{
    
    /**
     * Parámetros de un nodo
     */
    String value;
    Nodo<E> left;
    Nodo<E> right;

    /**
     * Construtor para definir los valores del nodo
     * @param value
     */
    public Nodo(String value) {
        this.value = value;
        right = null;
        left = null;
    }

    /** 
     * Se obtiene el valor de un nodo
     * @return E
     */
    public String getValue(){
        return value;
    }

}
