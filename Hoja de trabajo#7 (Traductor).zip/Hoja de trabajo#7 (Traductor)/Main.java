import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    
    private static Scanner scan;
    
    public static void main(String[] args) {
        
        scan = new Scanner(System.in);
        System.out.println("\n\t\t-----> Traductor VeryGoodNice <-----\n");
        System.out.println("Para comenzar necesito un archivo para alimentar el diccionario");
        
        boolean verificador1 = true;
        while(verificador1){     
            try {
                System.out.print("Ingresa el nombre del archivo por favor: ");
                String input = scan.nextLine();
                System.out.println();
                if(input.equals("diccionario.txt") || input.equals("Diccionario.txt")){
                    ArrayList<String> palabras = leerArchivo(input);
                    String temporal = ArchivoToString(palabras);
                    String[] lineas = temporal.split("\n");
                    String[] palabrasD;
                    for(int i = 0; i < lineas.length; i++){
                      palabrasD = lineas[i].split(",");

                      String keyIngles = palabrasD[0];
                      String valueIngles = "Ingles: " + palabrasD[0] + "\nEspanol: " + palabrasD[1] + "\nFrances: " + palabrasD[2];
                      Association<String, String> aso = new Association<String, String>(keyIngles, valueIngles);
                      


                      System.out.println(aso);

                    }
                    
                    verificador1 = false;
                } else {
                    System.out.println("Lo siento, este archivo no puede alimentar el diccionario");
                    System.out.println();
                    verificador1 = true;
                }

                System.out.println();
                boolean verificador2 = true;
                while(verificador2){
                  try {
                    System.out.println("En que idioma se encuentra el documento?: \n");
                    System.out.println("1) Espanol");
                    System.out.println("2) Ingles");
                    System.out.println("3) Frances\n");
                    System.out.print("Idioma: ");
                    String idioma = scan.nextLine();
                    if(idioma.equals("1")){
                      System.out.println("Entendido, el documento esta en: Espanol");
                      verificador2 = false;
                    } else if(idioma.equals("2")){
                      System.out.println("Entendido, el documento esta en: Ingles");
                      verificador2 = false;
                    } else if(idioma.equals("3")){
                      System.out.println("Entendido, el documento esta en: Frances");
                      verificador2 = false;
                    } else {
                      System.out.println("No es una opción válida lo siento\n");
                    }
                  } catch (Exception e) {
                    System.out.println("No es una opción válida lo siento\n");
                  }
                }
            } catch (Exception e) {
                System.out.println("ERROR!!! Archivo leido incorrectamente");
            }
          }
    }

  /**
  * Método leerArchivo
  * Se lee el contenido del archivo y se guarda en un ArrayList
  * @param nombreArchivo: Recibe el nombre del archivo 
  * @return: Arraylist con las lineas del archivo
  */
  public static ArrayList<String> leerArchivo(String nombreArchivo){

    /**
    * Se crea un Arraylist que almacenara cada linea del archivo
    */
    ArrayList<String> Info = new ArrayList<String>();

    /**
    * Try-catch como medida de seguridad por si en dado caso el archivo no existe
    */ 
    try {

      /**
      * Se lee cada linea del archivo y se agrega al ArrayList
      */
      File Archivo = new File(nombreArchivo);
      Scanner Lector = new Scanner(Archivo);

      while(Lector.hasNextLine()){
        String Line = Lector.nextLine();
        Info.add(Line);
      }

      Lector.close();
    } catch (Exception e){
      System.out.println("Error! Archivo no encontrado");
      e.printStackTrace();
    }


    return Info;
  }

  /**
  * Método ArchivoToString
  * Se convierte en un String el ArrayList de un archivo
  * @param Lista: Arraylist que contiene las lineas de un archivo
  * @return Acumulador: String que contiene toda la información del archivo
  */
  public static String ArchivoToString(ArrayList<String> Lista){
    /**
    * String vacío para acumular las lineas del archivo
    */
    String Acumulador = "";
    
    /**
    * Por cada linea del Arraylist se agrega la misma al Acumulador con un salto de
    * linea 
    */
    for(String a: Lista){
      Acumulador += (a + "\n");
    }
    Acumulador = Acumulador.trim();
    return Acumulador;
  }

}
